
import { GoogleGenAI } from "@google/genai";
import { Transaction } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getFinancialInsights = async (transactions: Transaction[]): Promise<string> => {
  if (transactions.length === 0) {
    return "Start adding transactions to get personalized financial insights!";
  }

  const transactionsSummary = transactions
    .slice(-10)
    .map(t => `${t.date}: ${t.type} of ${t.amount} for ${t.description} (${t.category})`)
    .join('\n');

  const prompt = `
    Analyze these recent financial transactions and provide 3 concise, actionable insights or tips:
    ${transactionsSummary}
    
    Format the response as a short bulleted list. Keep it encouraging and professional.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: "You are a professional financial advisor specializing in personal budgeting and accounting.",
        temperature: 0.7,
      }
    });

    return response.text || "I couldn't generate insights at this moment. Keep tracking your spending!";
  } catch (error) {
    console.error("Gemini Insight Error:", error);
    return "Error connecting to AI advisor. Please try again later.";
  }
};

export interface RateSource {
  title: string;
  uri: string;
}

export const getUSDTtoBDTRate = async (): Promise<{ rate: number; sources: RateSource[] }> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: "What is the current exchange rate for 1 USDT to BDT (Bangladeshi Taka)? Return only the numeric value.",
      config: {
        tools: [{ googleSearch: {} }],
      },
    });

    const text = response.text || "";
    const match = text.match(/(\d+(\.\d+)?)/);
    const rate = match ? parseFloat(match[0]) : 120.0;
    
    // Extract all web grounding sources
    const sources: RateSource[] = [];
    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    
    chunks.forEach(chunk => {
      if (chunk.web) {
        sources.push({
          title: chunk.web.title || "Exchange Rate Source",
          uri: chunk.web.uri
        });
      }
    });

    return { rate, sources };
  } catch (error) {
    console.error("Error fetching rate:", error);
    return { rate: 120.0, sources: [] };
  }
};
