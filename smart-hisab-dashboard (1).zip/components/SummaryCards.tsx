
import React from 'react';
import { FinancialSummary } from '../types';

interface SummaryCardsProps {
  summary: FinancialSummary;
  exchangeRate: number;
}

const SummaryCards: React.FC<SummaryCardsProps> = ({ summary, exchangeRate }) => {
  const toBDT = (usdt: number) => (usdt * exchangeRate).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      <div className="bg-white p-6 rounded-2xl shadow-sm border-l-4 border-indigo-500">
        <p className="text-sm font-medium text-slate-500 uppercase">Total Balance</p>
        <p className="text-2xl font-bold text-slate-800 mt-1">{summary.totalBalance.toLocaleString()} USDT</p>
        <p className="text-lg font-medium text-slate-400">৳ {toBDT(summary.totalBalance)} BDT</p>
      </div>
      <div className="bg-white p-6 rounded-2xl shadow-sm border-l-4 border-emerald-500">
        <p className="text-sm font-medium text-slate-500 uppercase">Total Income</p>
        <p className="text-2xl font-bold text-emerald-600 mt-1">+{summary.totalIncome.toLocaleString()} USDT</p>
        <p className="text-lg font-medium text-emerald-400">৳ {toBDT(summary.totalIncome)} BDT</p>
      </div>
      <div className="bg-white p-6 rounded-2xl shadow-sm border-l-4 border-rose-500">
        <p className="text-sm font-medium text-slate-500 uppercase">Total Expenses</p>
        <p className="text-2xl font-bold text-rose-600 mt-1">-{summary.totalExpense.toLocaleString()} USDT</p>
        <p className="text-lg font-medium text-rose-400">৳ {toBDT(summary.totalExpense)} BDT</p>
      </div>
    </div>
  );
};

export default SummaryCards;
