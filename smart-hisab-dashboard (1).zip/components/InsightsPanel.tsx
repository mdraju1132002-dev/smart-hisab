
import React, { useState } from 'react';
import { getFinancialInsights } from '../services/geminiService';
import { Transaction } from '../types';

interface InsightsPanelProps {
  transactions: Transaction[];
}

const InsightsPanel: React.FC<InsightsPanelProps> = ({ transactions }) => {
  const [insight, setInsight] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleGetInsight = async () => {
    setLoading(true);
    const result = await getFinancialInsights(transactions);
    setInsight(result);
    setLoading(false);
  };

  return (
    <div className="bg-gradient-to-br from-indigo-50 to-white p-6 rounded-2xl border border-indigo-100 mt-8">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <svg className="w-6 h-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
          <h2 className="text-xl font-bold text-slate-800">AI Financial Insights</h2>
        </div>
        <button
          onClick={handleGetInsight}
          disabled={loading}
          className="text-sm bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg font-medium transition-all disabled:opacity-50"
        >
          {loading ? 'Analyzing...' : 'Refresh Insights'}
        </button>
      </div>
      
      {insight ? (
        <div className="prose prose-sm text-slate-600 whitespace-pre-wrap">
          {insight}
        </div>
      ) : (
        <p className="text-slate-500 italic">Click the button to get personalized advice from Gemini AI based on your recent activity.</p>
      )}
    </div>
  );
};

export default InsightsPanel;
